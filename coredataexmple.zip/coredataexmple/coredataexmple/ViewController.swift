//
//  ViewController.swift
//  coredataexmple
//
//  Created by MACOS on 11/25/16.
//  Copyright © 2016 surat. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    
    @IBOutlet weak var txtempid: UITextField!
    
    @IBOutlet weak var txtempname: UITextField!
    
    
    @IBOutlet weak var txtempadd: UITextField!
    
let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        
     
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btninsert(_ sender: AnyObject) {
        
        
        let newcontact = NSEntityDescription.insertNewObject(forEntityName: "Employee", into: context) as NSManagedObject
        
        newcontact.setValue(txtempid.text, forKey: "emp_id");
        newcontact.setValue(txtempname.text, forKey: "emp_name");
        newcontact.setValue(txtempadd.text, forKey: "emp_add");
        
        do
        {
           try   context.save()
        }
        catch
        {
            
        }
    }
    
    @IBAction func btnupdate(_ sender: AnyObject) {
        
        
        let entitydis = NSEntityDescription.entity(forEntityName: "Employee", in: context);
        
    
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Employee")
        request.entity = entitydis;
        
        let pred = NSPredicate(format: "(emp_id= %@)", txtempid.text!);
        
      //  var err = NSError();
        
        request.predicate = pred;
        
        do{
            
        
            
            let results = try context.fetch(request);
            
            print(results);
            
            if results.count>0
            {
                
                let match =  results[0] as! NSManagedObject;
                match.setValue(txtempid.text, forKey: "emp_id");
                match.setValue(txtempname.text, forKey: "emp_name")
                match.setValue(txtempadd.text, forKey: "emp_add");
                
             try context.save()
            }
            else
            {
                print("not fount")
            }
        
            
        
         // let  groceries = results as![NSManagedObject]
  
           // print(groceries);
            
            
            
           /// tableView.reloadData()
        }catch{
            fatalError("Error is retriving Gorcery items")
        }
        
        
    }
    
    
    @IBAction func btndelete(_ sender: AnyObject) {
        
        let entitydis = NSEntityDescription.entity(forEntityName: "Employee", in: context);
        
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Employee")
        request.entity = entitydis;
        
        let pred = NSPredicate(format: "(emp_id= %@)", txtempid.text!);
        
        //  var err = NSError();
        
        request.predicate = pred;
        
        do{
            
            
            
            let results = try context.fetch(request);
            
            print(results);
            
            if results.count>0
            {
                
                let match =  results[0] as! NSManagedObject;
                
                
                
                context.delete(match);
                
              try context.save()
                
                
                
                
            }
            else
            {
                print("not fount")
            }
            
            
            
            // let  groceries = results as![NSManagedObject]
            
            // print(groceries);
            
            
            
            /// tableView.reloadData()
        }catch{
            fatalError("Error is retriving Gorcery items")
        }
        

    }
    
    @IBAction func btnselect(_ sender: AnyObject) {
        
        
        let entitydis = NSEntityDescription.entity(forEntityName: "Employee", in: context);
        
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Employee")
        request.entity = entitydis;
        
        let pred = NSPredicate(format: "(emp_id= %@)", txtempid.text!);
        
        //  var err = NSError();
        
        request.predicate = pred;
        
        do{
            
            
            
            let results = try context.fetch(request);
            
            print(results);
            
            if results.count>0
            {
                
                let match =  results[0] as! NSManagedObject;
                
                print(match.value(forKey: "emp_name"));
                print(match.value(forKey: "emp_id"));
                print(match.value(forKey: "emp_add"));
                
                txtempid.text = match.value(forKey: "emp_id") as?String
                
                txtempname.text = match.value(forKey: "emp_name") as? String
                txtempadd.text  = match.value(forKey: "emp_add") as? String
                
                
            }
            else
            {
                print("not fount")
            }
            
            
            
            // let  groceries = results as![NSManagedObject]
            
            // print(groceries);
            
            
            
            /// tableView.reloadData()
        }catch{
            fatalError("Error is retriving Gorcery items")
        }
        

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

